/**
 * @author  Srinivasan Devanathan 
 * @version 1.0
 * Webwork Javascript functions
 * 
 */

/**
 * Function to set values in the checkbox for the selections made by the User in
 * courses.jsp page.
 * 
 * @returns {Boolean}
 */
function generateSelectionCourses() {
	var drawerItemsNumber = drawer.model.getCurrentInstance()
			.getNumberOfItems();
	if (drawerItemsNumber > document.forms["courseAddForm"].selectedWebworkCoursesParam.length) {
		alert('You cannot select more items than the number of items available on this page. \n You can either go back to the previous page maintain your previous selections or unselect the items from the previous page.');
		return false;
	}

	var drawerSelectedItems = drawer.model.getCurrentInstance().getItems();

	for ( var loop = 0; loop < document.forms["courseAddForm"].selectedWebworkCoursesParam.length; loop++) {
		document.forms["courseAddForm"].selectedWebworkCoursesParam[loop].checked = false;
	}

	for ( var loop = 0; loop < drawerSelectedItems.length; loop++) {
		document.forms["courseAddForm"].selectedWebworkCoursesParam[loop].value = drawerSelectedItems[loop].itemId;
		document.forms["courseAddForm"].selectedWebworkCoursesParam[loop].checked = true;
	}
	document.forms["courseAddForm"].submit();
	return false;
}

/**
 * Function to set values in the checkbox for the selections made by the User in
 * sets.jsp page.
 * 
 * @returns {Boolean}
 */
function generateSelectionSets() {
	var drawerItemsNumber = drawer.model.getCurrentInstance()
			.getNumberOfItems();
	if (drawerItemsNumber > document.forms["setAddForm"].selectedWebworkSetsParam.length) {
		alert('You cannot select more items than the number of items available on this page. \n You can either go back to the previous page maintain your previous selections or unselect the items from the previous page.');
		return false;
	}

	var drawerSelectedItems = drawer.model.getCurrentInstance().getItems();

	for ( var loop = 0; loop < document.forms["setAddForm"].selectedWebworkSetsParam.length; loop++)
		document.forms["setAddForm"].selectedWebworkSetsParam[loop].checked = false;

	for ( var loop = 0; loop < drawerSelectedItems.length; loop++) {
		document.forms["setAddForm"].selectedWebworkSetsParam[loop].value = drawerSelectedItems[loop].itemId;
		document.forms["setAddForm"].selectedWebworkSetsParam[loop].checked = true;
	}
	document.forms["setAddForm"].submit();
	return false;
}

/**
 * Function to set values / display / select all in the checkbox for the
 * selections made by the User in assignments.jsp page.
 * 
 * @returns {Boolean}
 */
function selectCheckbox() {
	for ( var loop = 0; loop < document.forms["assignmentsForm"].isAvailable.length; loop++) {
		if (loop % 2 != 0) {
			if (document.forms["assignmentsForm"].isAvailable[loop].disabled == true) {
				if (document.forms["assignmentsForm"].isAvailable[loop - 1].checked == false) {
					document.forms["assignmentsForm"].isAvailable[loop].checked = true;
					document.forms["assignmentsForm"].isAvailable[loop].disabled = false;
					document.forms["assignmentsForm"].isAvailable[loop - 1].disabled = true;
				}
			} else {
				if (document.forms["assignmentsForm"].isAvailable[loop].checked == false) {
					document.forms["assignmentsForm"].isAvailable[loop - 1].checked = true;
					document.forms["assignmentsForm"].isAvailable[loop].disabled = true;
					document.forms["assignmentsForm"].isAvailable[loop - 1].disabled = false;
				}
			}
			if (document.forms["assignmentsForm"].createAnnouncement[loop].disabled == true) {
				if (document.forms["assignmentsForm"].createAnnouncement[loop - 1].checked == false) {
					document.forms["assignmentsForm"].createAnnouncement[loop].checked = true;
					document.forms["assignmentsForm"].createAnnouncement[loop].disabled = false;
					document.forms["assignmentsForm"].createAnnouncement[loop - 1].disabled = true;
				}
			} else {
				if (document.forms["assignmentsForm"].createAnnouncement[loop].checked == false) {
					document.forms["assignmentsForm"].createAnnouncement[loop - 1].checked = true;
					document.forms["assignmentsForm"].createAnnouncement[loop].disabled = true;
					document.forms["assignmentsForm"].createAnnouncement[loop - 1].disabled = false;
				}
			}
			if (document.forms["assignmentsForm"].isTracked[loop].disabled == true) {
				if (document.forms["assignmentsForm"].isTracked[loop - 1].checked == false) {
					document.forms["assignmentsForm"].isTracked[loop].checked = true;
					document.forms["assignmentsForm"].isTracked[loop].disabled = false;
					document.forms["assignmentsForm"].isTracked[loop - 1].disabled = true;
				}
			} else {
				if (document.forms["assignmentsForm"].isTracked[loop].checked == false) {
					document.forms["assignmentsForm"].isTracked[loop - 1].checked = true;
					document.forms["assignmentsForm"].isTracked[loop].disabled = true;
					document.forms["assignmentsForm"].isTracked[loop - 1].disabled = false;
				}
			}
		}
	}
}

/**
 * Function to display error message when user attempts to change date on
 * assignments.jsp.
 * 
 */
function errorSelection() {
	window
			.alert("Are you sure you want to change the dates? THIS IS TEST VERSION, SET MIGHT EVEN BE DELETED."
					+ "If yes, change to a valid date. \n"
					+ "Know that you can also modify date later through Content -> Edit");
}

/**
 * Function to make changes to partialcredit and partial dates. When the user
 * selects the checkbox, the date and percent text box are enabled on
 * assignments.jsp
 */
function changePartial() {
	var length = (document.forms["assignmentsForm"].isAvailable.length / 2);
	if (length > 1) {
		for ( var loop = 0; loop < length; loop++) {
			if (document.forms["assignmentsForm"].enablePartial[loop].checked == true) {
				document.forms["assignmentsForm"].partialDate[loop].disabled = false;
				document.forms["assignmentsForm"].partialPercent[loop].disabled = false;
				return true;
			} else {
				document.forms["assignmentsForm"].partialDate[loop].disabled = true;
				document.forms["assignmentsForm"].partialPercent[loop].disabled = true;
				return true;
			}
		}
	} else if (document.forms["assignmentsForm"].enablePartial.checked == true) {
		document.forms["assignmentsForm"].partialDate.disabled = false;
		document.forms["assignmentsForm"].partialPercent.disabled = false;
		return true;
	} else {
		document.forms["assignmentsForm"].partialDate.disabled = true;
		document.forms["assignmentsForm"].partialPercent.disabled = true;
		return true;
	}
}

/**
 * Function to validate assignments.jsp form.
 * 
 * @returns {Boolean}
 */
function validateForm() {
	var length = (document.forms["assignmentsForm"].isAvailable.length / 2);
	if (length > 1) {
		for ( var loop = 0; loop < length; loop++) {
			if (document.forms["assignmentsForm"].name[loop].value == "") {
				window.alert("Assignment name cannot be empty");
				document.forms["assignmentsForm"].name[loop].focus();
				return false;
			}
			if (document.forms["assignmentsForm"].pointsPossible[loop].value == 0) {
				window.alert("Grades can only have a non-zero value.");
				document.forms["assignmentsForm"].pointsPossible[loop].focus();
				return false;
			}
			if (document.forms["assignmentsForm"].startDate[loop].value == ""
					|| document.forms["assignmentsForm"].endDate[loop].value == ""
					|| (document.forms["assignmentsForm"].partialDate[loop].disabled == false && document.forms["assignmentsForm"].partialDate[loop].value == "")) {
				window.alert("Assignment Dates cannot be empty.");
				return false;
			}
			if (document.forms["assignmentsForm"].type[loop].value != "Assignment") {
				window.alert("Assignment is the only type available right now");
				document.forms["assignmentsForm"].type[loop].focus();
				return false;
			}
		}
	} else {
		if (document.forms["assignmentsForm"].name.value == "") {
			window.alert("Assignment name cannot be empty");
			document.forms["assignmentsForm"].name.focus();
			return false;
		}
		if (document.forms["assignmentsForm"].pointsPossible.value == 0) {
			window.alert("Grades can only have a non-zero value.");
			document.forms["assignmentsForm"].pointsPossible.focus();
			return false;
		}
		if (document.forms["assignmentsForm"].startDate.value == ""
				|| document.forms["assignmentsForm"].endDate.value == ""
				|| (document.forms["assignmentsForm"].partialDate.disabled == false && document.forms["assignmentsForm"].partialDate.value == "")) {
			window.alert("Assignment Dates cannot be empty.");
			return false;
		}
		if (document.forms["assignmentsForm"].type.value == ""
				|| document.forms["assignmentsForm"].type.value.toUpperCase() != "Assignment"
						.toUpperCase()) {
			window.alert("Assignment is the only type available right now.");
			document.forms["assignmentsForm"].type.focus();
			return false;
		}
	}
	return true;
}

/**
 * Function to display the text box on the selection of radio button.
 * 
 */
function displayOtherElements() {
	var checked = document.forms["configForm"].webworkCoursesSearchMethod[0].checked;
	if (checked == true) {
		document.forms["configForm"].webworkSearchCourse.disabled = false;
		document.forms["configForm"].webworkInstructorPermissionLevel.disabled = true;
	}
	var checked = document.forms["configForm"].webworkCoursesSearchMethod[1].checked;
	if (checked == true) {
		document.forms["configForm"].webworkInstructorPermissionLevel.disabled = false;
		document.forms["configForm"].webworkSearchCourse.disabled = true;
	}
	var checked = document.forms["configForm"].webworkCoursesSearchMethod[2].checked;
	if (checked == true) {
		document.forms["configForm"].webworkInstructorPermissionLevel.disabled = true;
		document.forms["configForm"].webworkSearchCourse.disabled = true;
	}
}

/**
 * Function to change the webserver variables when one changes the SOAP.
 */
function copyVariable() {
	document.forms["configForm"].soapAuthKey.value = new jsUri(
			'http://www.test.com').setHost('www.yahoo.com')
			.setProtocol('https');
	document.forms["configForm"].webServerSiteUrl.value = document.forms["configForm"].webServerLocation.value;
}